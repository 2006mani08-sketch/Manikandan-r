<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modern Portfolio</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        :root {
            --primary: #6C63FF;
            --secondary: #4A40E0;
            --accent: #FF6584;
            --dark: #2A2A3C;
            --light: #F5F5F7;
            --text: #333344;
        }

        body {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            color: var(--light);
            line-height: 1.6;
            overflow-x: hidden;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        /* Header & Navigation */
        header {
            padding: 20px 0;
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000;
            transition: all 0.4s ease;
            backdrop-filter: blur(10px);
            background: rgba(26, 26, 46, 0.8);
        }

        header.scrolled {
            padding: 10px 0;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
        }

        nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            font-size: 28px;
            font-weight: 700;
            color: var(--primary);
            text-decoration: none;
        }

        .logo span {
            color: var(--accent);
        }

        .nav-links {
            display: flex;
            list-style: none;
        }

        .nav-links li {
            margin-left: 30px;
        }

        .nav-links a {
            color: var(--light);
            text-decoration: none;
            font-weight: 500;
            font-size: 18px;
            transition: color 0.3s ease;
            position: relative;
        }

        .nav-links a:hover {
            color: var(--primary);
        }

        .nav-links a::after {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            bottom: -5px;
            left: 0;
            background-color: var(--primary);
            transition: width 0.3s ease;
        }

        .nav-links a:hover::after {
            width: 100%;
        }

        /* Hero Section */
        .hero {
            height: 100vh;
            display: flex;
            align-items: center;
            padding-top: 80px;
            position: relative;
            overflow: hidden;
        }

        .hero::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: radial-gradient(circle at center, rgba(108, 99, 255, 0.1) 0%, transparent 70%);
            z-index: -1;
        }

        .hero-content {
            max-width: 600px;
            animation: fadeInUp 1s ease-out;
        }

        .hero h1 {
            font-size: 64px;
            margin-bottom: 20px;
            line-height: 1.2;
        }

        .hero h1 span {
            color: var(--primary);
        }

        .hero p {
            font-size: 20px;
            margin-bottom: 30px;
            color: #ccd6f6;
        }

        .btn {
            display: inline-block;
            background: var(--primary);
            color: white;
            padding: 14px 32px;
            border-radius: 50px;
            text-decoration: none;
            font-weight: 600;
            font-size: 18px;
            transition: all 0.3s ease;
            border: 2px solid transparent;
            box-shadow: 0 10px 20px rgba(108, 99, 255, 0.3);
        }

        .btn:hover {
            background: transparent;
            border-color: var(--primary);
            transform: translateY(-5px);
            box-shadow: 0 15px 25px rgba(108, 99, 255, 0.4);
        }

        .social-icons {
            display: flex;
            margin-top: 40px;
        }

        .social-icons a {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.1);
            color: white;
            font-size: 20px;
            margin-right: 15px;
            transition: all 0.3s ease;
        }

        .social-icons a:hover {
            background: var(--primary);
            transform: translateY(-5px);
        }

        /* About Section */
        section {
            padding: 100px 0;
        }

        .section-title {
            text-align: center;
            font-size: 40px;
            margin-bottom: 70px;
            position: relative;
        }

        .section-title::after {
            content: '';
            position: absolute;
            width: 80px;
            height: 4px;
            background: var(--primary);
            bottom: -15px;
            left: 50%;
            transform: translateX(-50%);
            border-radius: 2px;
        }

        .about-content {
            display: flex;
            align-items: center;
            gap: 50px;
        }

        .about-img {
            flex: 1;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
            animation: float 6s ease-in-out infinite;
        }

        .about-img img {
            width: 100%;
            height: auto;
            display: block;
        }

        .about-text {
            flex: 1;
        }

        .about-text h3 {
            font-size: 32px;
            margin-bottom: 20px;
            color: var(--primary);
        }

        .about-text p {
            margin-bottom: 20px;
            font-size: 18px;
            color: #ccd6f6;
        }

        /* Skills Section */
        .skills {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 20px;
            padding: 40px;
        }

        .skills-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            gap: 30px;
            margin-top: 40px;
        }

        .skill-card {
            background: rgba(255, 255, 255, 0.08);
            border-radius: 15px;
            padding: 25px;
            text-align: center;
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .skill-card:hover {
            transform: translateY(-10px);
            background: rgba(108, 99, 255, 0.2);
        }

        .skill-card i {
            font-size: 50px;
            margin-bottom: 15px;
            color: var(--primary);
        }

        .skill-card h4 {
            font-size: 18px;
            font-weight: 600;
        }

        /* Projects Section */
        .projects-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 40px;
        }

        .project-card {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 20px;
            overflow: hidden;
            transition: all 0.4s ease;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        }

        .project-card:hover {
            transform: translateY(-15px);
            box-shadow: 0 20px 40px rgba(108, 99, 255, 0.3);
        }

        .project-img {
            height: 250px;
            overflow: hidden;
        }

        .project-img img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.5s ease;
        }

        .project-card:hover .project-img img {
            transform: scale(1.1);
        }

        .project-info {
            padding: 25px;
        }

        .project-info h3 {
            font-size: 24px;
            margin-bottom: 15px;
        }

        .project-info p {
            margin-bottom: 20px;
            color: #ccd6f6;
        }

        .tags {
            display: flex;
            flex-wrap: wrap;
            margin-bottom: 20px;
        }

        .tag {
            background: rgba(108, 99, 255, 0.2);
            color: var(--primary);
            padding: 5px 15px;
            border-radius: 50px;
            font-size: 14px;
            margin-right: 10px;
            margin-bottom: 10px;
        }

        /* Contact Section */
        .contact {
            text-align: center;
        }

        .contact-form {
            max-width: 600px;
            margin: 0 auto;
        }

        .form-group {
            margin-bottom: 25px;
        }

        input, textarea {
            width: 100%;
            padding: 18px;
            border: none;
            background: rgba(255, 255, 255, 0.08);
            border-radius: 10px;
            font-size: 18px;
            color: white;
            transition: all 0.3s ease;
        }

        input:focus, textarea:focus {
            outline: none;
            background: rgba(255, 255, 255, 0.12);
            box-shadow: 0 0 0 2px var(--primary);
        }

        textarea {
            min-height: 150px;
            resize: vertical;
        }

        /* Footer */
        footer {
            background: rgba(10, 10, 20, 0.8);
            padding: 40px 0 20px;
            text-align: center;
        }

        .footer-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        .footer-logo {
            font-size: 24px;
            font-weight: 700;
            color: var(--primary);
        }

        .footer-links a {
            color: var(--light);
            margin-left: 20px;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .footer-links a:hover {
            color: var(--primary);
        }

        .copyright {
            padding-top: 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            color: #ccd6f6;
            font-size: 16px;
        }

        /* Animations */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(50px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes float {
            0% {
                transform: translateY(0px);
            }
            50% {
                transform: translateY(-20px);
            }
            100% {
                transform: translateY(0px);
            }
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .hero h1 {
                font-size: 48px;
            }
            
            .about-content {
                flex-direction: column;
            }
            
            .projects-grid {
                grid-template-columns: 1fr;
            }
            
            .footer-content {
                flex-direction: column;
                gap: 20px;
            }
            
            .nav-links {
                display: none;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header>
        <div class="container">
            <nav>
                <a href="#" class="logo">Port<span>folio</span></a>
                <ul class="nav-links">
                    <li><a href="#home">Home</a></li>
                    <li><a href="#about">About</a></li>
                    <li><a href="#skills">Skills</a></li>
                    <li><a href="#projects">Projects</a></li>
                    <li><a href="#contact">Contact</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Hero Section -->
    <section id="home" class="hero">
        <div class="container">
            <div class="hero-content">
                <h1>Hello, I'm <span>manikandan</span><br>Web Developer</h1>
                <p>I create beautiful, functional websites with modern technologies and user experience in mind. Let's build something amazing together!</p>
                <a href="#projects" class="btn">View My Work</a>
                <div class="social-icons">
                   
                    <a href="#"><i class="fab fa-instagram"></i></a>
                </div>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section id="about" class="about">
        <div class="container">
            <h2 class="section-title">About Me</h2>
            <div class="about-content">
                <div class="about-img">
                    <img src=https://i.ibb.co/KxmHGq5F/IMG-20240529-100518-645.jpg alt="Profile">
                </div>
                <div class="about-text">
                    <h3>A passionate developer </h3>
                    <p>Hello! I'm manikandan, a web developer , I specialize in creating modern web applications using the latest technologies.</p>
                    <p>My approach combines technical expertise with creative problem-solving to deliver solutions that not only look great but also perform exceptionally well across all devices.</p>
                    <p>When I'm not coding, you'll find me hiking, reading tech blogs, or experimenting with new web development techniques.</p>
                    <a href="#contact" class="btn">Get In Touch</a>
                </div>
            </div>
        </div>
    </section>

    <!-- Skills Section -->
    <section id="skills" class="skills">
        <div class="container">
            <h2 class="section-title">My Skills</h2>
            <div class="skills-grid">
                <div class="skill-card">
                    <i class="fab fa-html5"></i>
                    <h4>HTML5</h4>
                </div>
                <div class="skill-card">
                    <i class="fab fa-css3-alt"></i>
                    <h4>CSS3</h4>
                </div>
                <div class="skill-card">
                    <i class="fab fa-js"></i>
                    <h4>JavaScript</h4>
                </div>
   
                <div class="skill-card">
                    <i class="fas fa-c++"></i>
                    <h4>C++</h4>
                </div>
                <div class="skill-card">
                    <i class="fab fa-c-alt"></i>
                    <h4>C</h4>
                </div>
            </div>
        </div>
    </section>

    
   
                      

    <!-- Contact Section -->
    <section id="contact" class="contact">
        <div class="container">
            <h2 class="section-title">Get In Touch</h2>
            <div class="contact-form">
                <form>
                    <div class="form-group">
                        <input type="text" placeholder="Your Name" required>
                    </div>
                    <div class="form-group">
                        <input type="email" placeholder="Your Email" required>
                    </div>
                    <div class="form-group">
                        <input type="text" placeholder="Subject">
                    </div>
                    <div class="form-group">
                        <textarea placeholder="Your Message" required></textarea>
                    </div>
                    <button type="submit" class="btn">Send Message</button>
                </form>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-logo">Port<span>folio</span></div>
                <div class="footer-links">
                    <a href="#home">Home</a>
                    <a href="#about">About</a>
                    <a href="#skills">Skills</a>
                    <a href="#projects">Projects</a>
                    <a href="#contact">Contact</a>
                </div>
            </div>
            <div class="copyright">
                <p>&copy; 2024manikandan All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script>
        // Header scroll effect
        window.addEventListener('scroll', function() {
            const header = document.querySelector('header');
            if (window.scrollY > 50) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        });

        // Smooth scrolling for navigation links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                
                const targetId = this.getAttribute('href');
                const targetElement = document.querySelector(targetId);
                
                window.scrollTo({
                    top: targetElement.offsetTop - 80,
                    behavior: 'smooth'
                });
            });
        });

        // Animation on scroll
        const animateOnScroll = function() {
            const elements = document.querySelectorAll('.skill-card, .project-card, .about-img');
            
            elements.forEach(element => {
                const elementPosition = element.getBoundingClientRect().top;
                const screenPosition = window.innerHeight / 1.3;
                
                if (elementPosition < screenPosition) {
                    element.style.opacity = '1';
                    element.style.transform = 'translateY(0)';
                }
            });
        };

        // Set initial state for animated elements
        document.querySelectorAll('.skill-card, .project-card, .about-img').forEach(el => {
            el.style.opacity = '0';
            el.style.transform = 'translateY(50px)';
            el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        });

        window.addEventListener('scroll', animateOnScroll);
        window.addEventListener('load', animateOnScroll);
    </script>
</body>
</html>        // Set initial state for animated elements
        document.querySelectorAll('.skill-card, .project-card, .about-img').forEach(el => {
            el.style.opacity = '0';
            el.style.transform = 'translateY(50px)';
            el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        });

        window.addEventListener('scroll', animateOnScroll);
        window.addEventListener('load', animateOnScroll);
    </script>
</body>
</html><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modern Portfolio</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        :root {
            --primary: #6C63FF;
            --secondary: #4A40E0;
            --accent: #FF6584;
            --dark: #2A2A3C;
            --light: #F5F5F7;
            --text: #333344;
        }

        body {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            color: var(--light);
            line-height: 1.6;
            overflow-x: hidden;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        /* Header & Navigation */
        header {
            padding: 20px 0;
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000;
            transition: all 0.4s ease;
            backdrop-filter: blur(10px);
            background: rgba(26, 26, 46, 0.8);
        }

        header.scrolled {
            padding: 10px 0;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
        }

        nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            font-size: 28px;
            font-weight: 700;
            color: var(--primary);
            text-decoration: none;
        }

        .logo span {
            color: var(--accent);
        }

        .nav-links {
            display: flex;
            list-style: none;
        }

        .nav-links li {
            margin-left: 30px;
        }

        .nav-links a {
            color: var(--light);
            text-decoration: none;
            font-weight: 500;
            font-size: 18px;
            transition: color 0.3s ease;
            position: relative;
        }

        .nav-links a:hover {
            color: var(--primary);
        }

        .nav-links a::after {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            bottom: -5px;
            left: 0;
            background-color: var(--primary);
            transition: width 0.3s ease;
        }

        .nav-links a:hover::after {
            width: 100%;
        }

        /* Hero Section */
        .hero {
            height: 100vh;
            display: flex;
            align-items: center;
            padding-top: 80px;
            position: relative;
            overflow: hidden;
        }

        .hero::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: radial-gradient(circle at center, rgba(108, 99, 255, 0.1) 0%, transparent 70%);
            z-index: -1;
        }

        .hero-content {
            max-width: 600px;
            animation: fadeInUp 1s ease-out;
        }

        .hero h1 {
            font-size: 64px;
            margin-bottom: 20px;
            line-height: 1.2;
        }

        .hero h1 span {
            color: var(--primary);
        }

        .hero p {
            font-size: 20px;
            margin-bottom: 30px;
            color: #ccd6f6;
        }

        .btn {
            display: inline-block;
            background: var(--primary);
            color: white;
            padding: 14px 32px;
            border-radius: 50px;
            text-decoration: none;
            font-weight: 600;
            font-size: 18px;
            transition: all 0.3s ease;
            border: 2px solid transparent;
            box-shadow: 0 10px 20px rgba(108, 99, 255, 0.3);
        }

        .btn:hover {
            background: transparent;
            border-color: var(--primary);
            transform: translateY(-5px);
            box-shadow: 0 15px 25px rgba(108, 99, 255, 0.4);
        }

        .social-icons {
            display: flex;
            margin-top: 40px;
        }

        .social-icons a {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.1);
            color: white;
            font-size: 20px;
            margin-right: 15px;
            transition: all 0.3s ease;
        }

        .social-icons a:hover {
            background: var(--primary);
            transform: translateY(-5px);
        }

        /* About Section */
        section {
            padding: 100px 0;
        }

        .section-title {
            text-align: center;
            font-size: 40px;
            margin-bottom: 70px;
            position: relative;
        }

        .section-title::after {
            content: '';
            position: absolute;
            width: 80px;
            height: 4px;
            background: var(--primary);
            bottom: -15px;
            left: 50%;
            transform: translateX(-50%);
            border-radius: 2px;
        }

        .about-content {
            display: flex;
            align-items: center;
            gap: 50px;
        }

        .about-img {
            flex: 1;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
            animation: float 6s ease-in-out infinite;
        }

        .about-img img {
            width: 100%;
            height: auto;
            display: block;
        }

        .about-text {
            flex: 1;
        }

        .about-text h3 {
            font-size: 32px;
            margin-bottom: 20px;
            color: var(--primary);
        }

        .about-text p {
            margin-bottom: 20px;
            font-size: 18px;
            color: #ccd6f6;
        }

        /* Skills Section */
        .skills {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 20px;
            padding: 40px;
        }

        .skills-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            gap: 30px;
            margin-top: 40px;
        }

        .skill-card {
            background: rgba(255, 255, 255, 0.08);
            border-radius: 15px;
            padding: 25px;
            text-align: center;
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .skill-card:hover {
            transform: translateY(-10px);
            background: rgba(108, 99, 255, 0.2);
        }

        .skill-card i {
            font-size: 50px;
            margin-bottom: 15px;
            color: var(--primary);
        }

        .skill-card h4 {
            font-size: 18px;
            font-weight: 600;
        }

        /* Projects Section */
        .projects-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 40px;
        }

        .project-card {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 20px;
            overflow: hidden;
            transition: all 0.4s ease;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        }

        .project-card:hover {
            transform: translateY(-15px);
            box-shadow: 0 20px 40px rgba(108, 99, 255, 0.3);
        }

        .project-img {
            height: 250px;
            overflow: hidden;
        }

        .project-img img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.5s ease;
        }

        .project-card:hover .project-img img {
            transform: scale(1.1);
        }

        .project-info {
            padding: 25px;
        }

        .project-info h3 {
            font-size: 24px;
            margin-bottom: 15px;
        }

        .project-info p {
            margin-bottom: 20px;
            color: #ccd6f6;
        }

        .tags {
            display: flex;
            flex-wrap: wrap;
            margin-bottom: 20px;
        }

        .tag {
            background: rgba(108, 99, 255, 0.2);
            color: var(--primary);
            padding: 5px 15px;
            border-radius: 50px;
            font-size: 14px;
            margin-right: 10px;
            margin-bottom: 10px;
        }

        /* Contact Section */
        .contact {
            text-align: center;
        }

        .contact-form {
            max-width: 600px;
            margin: 0 auto;
        }

        .form-group {
            margin-bottom: 25px;
        }

        input, textarea {
            width: 100%;
            padding: 18px;
            border: none;
            background: rgba(255, 255, 255, 0.08);
            border-radius: 10px;
            font-size: 18px;
            color: white;
            transition: all 0.3s ease;
        }

        input:focus, textarea:focus {
            outline: none;
            background: rgba(255, 255, 255, 0.12);
            box-shadow: 0 0 0 2px var(--primary);
        }

        textarea {
            min-height: 150px;
            resize: vertical;
        }

        /* Footer */
        footer {
            background: rgba(10, 10, 20, 0.8);
            padding: 40px 0 20px;
            text-align: center;
        }

        .footer-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        .footer-logo {
            font-size: 24px;
            font-weight: 700;
            color: var(--primary);
        }

        .footer-links a {
            color: var(--light);
            margin-left: 20px;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .footer-links a:hover {
            color: var(--primary);
        }

        .copyright {
            padding-top: 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            color: #ccd6f6;
            font-size: 16px;
        }

        /* Animations */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(50px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes float {
            0% {
                transform: translateY(0px);
            }
            50% {
                transform: translateY(-20px);
            }
            100% {
                transform: translateY(0px);
            }
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .hero h1 {
                font-size: 48px;
            }
            
            .about-content {
                flex-direction: column;
            }
            
            .projects-grid {
                grid-template-columns: 1fr;
            }
            
            .footer-content {
                flex-direction: column;
                gap: 20px;
            }
            
            .nav-links {
                display: none;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header>
        <div class="container">
            <nav>
                <a href="#" class="logo">Port<span>folio</span></a>
                <ul class="nav-links">
                    <li><a href="#home">Home</a></li>
                    <li><a href="#about">About</a></li>
                    <li><a href="#skills">Skills</a></li>
                    <li><a href="#projects">Projects</a></li>
                    <li><a href="#contact">Contact</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Hero Section -->
    <section id="home" class="hero">
        <div class="container">
            <div class="hero-content">
                <h1>Hello, I'm <span>manikandan</span><br>Web Developer</h1>
                <p>I create beautiful, functional websites with modern technologies and user experience in mind. Let's build something amazing together!</p>
                <a href="#projects" class="btn">View My Work</a>
                <div class="social-icons">
                   
                    <a href="#"><i class="fab fa-instagram"></i></a>
                </div>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section id="about" class="about">
        <div class="container">
            <h2 class="section-title">About Me</h2>
            <div class="about-content">
                <div class="about-img">
                    <img src=https://i.ibb.co/KxmHGq5F/IMG-20240529-100518-645.jpg alt="Profile">
                </div>
                <div class="about-text">
                    <h3>A passionate developer </h3>
                    <p>Hello! I'm manikandan, a web developer , I specialize in creating modern web applications using the latest technologies.</p>
                    <p>My approach combines technical expertise with creative problem-solving to deliver solutions that not only look great but also perform exceptionally well across all devices.</p>
                    <p>When I'm not coding, you'll find me hiking, reading tech blogs, or experimenting with new web development techniques.</p>
                    <a href="#contact" class="btn">Get In Touch</a>
                </div>
            </div>
        </div>
    </section>

    <!-- Skills Section -->
    <section id="skills" class="skills">
        <div class="container">
            <h2 class="section-title">My Skills</h2>
            <div class="skills-grid">
                <div class="skill-card">
                    <i class="fab fa-html5"></i>
                    <h4>HTML5</h4>
                </div>
                <div class="skill-card">
                    <i class="fab fa-css3-alt"></i>
                    <h4>CSS3</h4>
                </div>
                <div class="skill-card">
                    <i class="fab fa-js"></i>
                    <h4>JavaScript</h4>
                </div>
   
                <div class="skill-card">
                    <i class="fas fa-c++"></i>
                    <h4>C++</h4>
                </div>
                <div class="skill-card">
                    <i class="fab fa-c-alt"></i>
                    <h4>C</h4>
                </div>
            </div>
        </div>
    </section>

    
   
                      

    <!-- Contact Section -->
    <section id="contact" class="contact">
        <div class="container">
            <h2 class="section-title">Get In Touch</h2>
            <div class="contact-form">
                <form>
                    <div class="form-group">
                        <input type="text" placeholder="Your Name" required>
                    </div>
                    <div class="form-group">
                        <input type="email" placeholder="Your Email" required>
                    </div>
                    <div class="form-group">
                        <input type="text" placeholder="Subject">
                    </div>
                    <div class="form-group">
                        <textarea placeholder="Your Message" required></textarea>
                    </div>
                    <button type="submit" class="btn">Send Message</button>
                </form>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-logo">Port<span>folio</span></div>
                <div class="footer-links">
                    <a href="#home">Home</a>
                    <a href="#about">About</a>
                    <a href="#skills">Skills</a>
                    <a href="#projects">Projects</a>
                    <a href="#contact">Contact</a>
                </div>
            </div>
            <div class="copyright">
                <p>&copy; 2024manikandan All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script>
        // Header scroll effect
        window.addEventListener('scroll', function() {
            const header = document.querySelector('header');
            if (window.scrollY > 50) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        });

        // Smooth scrolling for navigation links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                
                const targetId = this.getAttribute('href');
                const targetElement = document.querySelector(targetId);
                
                window.scrollTo({
                    top: targetElement.offsetTop - 80,
                    behavior: 'smooth'
                });
            });
        });

        // Animation on scroll
        const animateOnScroll = function() {
            const elements = document.querySelectorAll('.skill-card, .project-card, .about-img');
            
            elements.forEach(element => {
                const elementPosition = element.getBoundingClientRect().top;
                const screenPosition = window.innerHeight / 1.3;
                
                if (elementPosition < screenPosition) {
                    element.style.opacity = '1';
                    element.style.transform = 'translateY(0)';
                }
            });
        };

        // Set initial state for animated elements
        document.querySelectorAll('.skill-card, .project-card, .about-img').forEach(el => {
            el.style.opacity = '0';
            el.style.transform = 'translateY(50px)';
            el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        });

        window.addEventListener('scroll', animateOnScroll);
        window.addEventListener('load', animateOnScroll);
    </script>
</body>
</html>        // Set initial state for animated elements
        document.querySelectorAll('.skill-card, .project-card, .about-img').forEach(el => {
            el.style.opacity = '0';
            el.style.transform = 'translateY(50px)';
            el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        });

        window.addEventListener('scroll', animateOnScroll);
        window.addEventListener('load', animateOnScroll);
    </script>
</body>
</html>